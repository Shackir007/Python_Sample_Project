def add_one(number):
    print("Message from Packagingtutorial")
    return number + 1